# Como executar

1- entrar na pasta 

2- executar `mvn compile`

3- executar `make run sim=App`
